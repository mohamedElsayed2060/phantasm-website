// src/app/(frontend)/layout.jsx
import './frontend.css'
import { getFrontendGlobals } from '@/lib/cms'
import FrontendOverlays from '@/components/overlays/FrontendOverlays'
import SplashManagerClient from '@/components/overlays/SplashManagerClient'

export const dynamic = 'force-dynamic'
export const metadata = {
  title: {
    default: 'PHANTASM',
    template: '%s | PHANTASM',
  },
  description:
    'We specialise in creating engaging games and software applications that bring your ideas to life.',
}

export default async function FrontendLayout({ children }) {
  const globals = await getFrontendGlobals()

  return (
    <div className="min-h-screen silkscreen-font bg-black text-white overflow-hidden relative">
      {/* SSR splash shell */}
      <div
        id="ssr-splash"
        className="fixed inset-0 z-[10050] flex items-center justify-center bg-black"
        style={{
          backgroundImage: 'url(/intro.jpg)',
          backgroundRepeat: 'no-repeat',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="flex flex-col items-center gap-4">
          {/* <img
            src={logoUrl}
            alt={companyName}
            draggable={false}
            className="w-[140px] h-auto select-none"
            style={{ imageRendering: 'pixelated' }}
          /> */}
          {/* <div className="text-white/80 tracking-[0.24em] text-xs">{companyName}</div> */}
          <div className="mt-2 h-[2px] w-[160px] overflow-hidden bg-white/10 rounded">
            <div className="h-full w-1/3 bg-white/60 animate-[phantasmBar_0.9s_linear_infinite]" />
          </div>
        </div>
      </div>

      {/* ✅ Splash manager فقط */}
      <SplashManagerClient />
      <FrontendOverlays globals={globals} />

      {/* ✅ مباشرة بدون PageTransition */}
      {children}
    </div>
  )
}
