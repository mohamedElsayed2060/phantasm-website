export default function Page() {
  return <div>About Us page</div>
}
