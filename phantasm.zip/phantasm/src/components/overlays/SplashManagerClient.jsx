'use client'

import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { usePathname } from 'next/navigation'
import SplashOverlay from './SplashOverlay'

const ENV_MIN = Number(process.env.NEXT_PUBLIC_SPLASH_MIN_MS)
const ENV_HOLD = Number(process.env.NEXT_PUBLIC_SPLASH_HOLD_AFTER_READY_MS)

function isIslandReadyRoute(pathname) {
  return pathname === '/' || pathname === '/island-custom-test'
}

export default function SplashManagerClient({
  defaultMinMs = 1850,
  holdAfterReadyMs = 300,
  maxWaitMs = 9000,
}) {
  const pathname = usePathname()

  const minMs = Number.isFinite(ENV_MIN) && ENV_MIN > 0 ? ENV_MIN : defaultMinMs
  const holdMs = Number.isFinite(ENV_HOLD) && ENV_HOLD >= 0 ? ENV_HOLD : holdAfterReadyMs

  const [open, setOpen] = useState(true)
  const [isInstant, setIsInstant] = useState(true)

  const openedAtRef = useRef(Date.now())
  const readyRef = useRef(false)
  const closeTimerRef = useRef(null)
  const forceCloseTimerRef = useRef(null)
  const handedOffRef = useRef(false)
  const modeRef = useRef('boot')
  const cleanupReadyRef = useRef(() => {})
  const clickNavArmedRef = useRef(false)

  const clearClose = () => {
    if (closeTimerRef.current) clearTimeout(closeTimerRef.current)
    closeTimerRef.current = null

    if (forceCloseTimerRef.current) clearTimeout(forceCloseTimerRef.current)
    forceCloseTimerRef.current = null

    try {
      cleanupReadyRef.current?.()
    } catch {}

    cleanupReadyRef.current = () => {}
  }

  const scheduleClose = () => {
    if (!readyRef.current) return

    const elapsed = Date.now() - (openedAtRef.current || Date.now())
    const remaining = Math.max(0, minMs - elapsed)
    const wait = remaining + Math.max(0, holdMs)

    if (closeTimerRef.current) clearTimeout(closeTimerRef.current)
    closeTimerRef.current = setTimeout(() => {
      setOpen(false)
    }, wait)
  }

  const openBoot = () => {
    clearClose()
    modeRef.current = 'boot'
    setIsInstant(true)
    openedAtRef.current = Date.now()
    readyRef.current = false
    setOpen(true)

    try {
      sessionStorage.removeItem('phantasm:sceneReady')
      sessionStorage.removeItem('phantasm:splashFullyClosed')
      window.dispatchEvent(new CustomEvent('phantasm:splashOpened'))
    } catch {}
  }

  const openNav = (isBackAction = false) => {
    clearClose()
    modeRef.current = 'nav'
    setIsInstant(isBackAction)
    openedAtRef.current = Date.now()
    readyRef.current = false
    setOpen(true)

    try {
      sessionStorage.removeItem('phantasm:sceneReady')
      sessionStorage.removeItem('phantasm:splashFullyClosed')
      window.dispatchEvent(new CustomEvent('phantasm:splashOpened'))
    } catch {}
  }

  const waitForIslandReady = () => {
    try {
      sessionStorage.removeItem('phantasm:sceneReady')
    } catch {}

    const onReady = () => {
      window.removeEventListener('phantasm:sceneReady', onReady)
      readyRef.current = true
      scheduleClose()

      if (forceCloseTimerRef.current) clearTimeout(forceCloseTimerRef.current)
      forceCloseTimerRef.current = null
    }

    window.addEventListener('phantasm:sceneReady', onReady)
    cleanupReadyRef.current = () => window.removeEventListener('phantasm:sceneReady', onReady)
  }

  useEffect(() => {
    if (handedOffRef.current) return
    handedOffRef.current = true

    const removeSsr = () => {
      const el = document.getElementById('ssr-splash')
      if (!el) return
      el.style.transition = 'opacity 180ms ease'
      el.style.opacity = '0'
      setTimeout(() => el.remove(), 220)
    }

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        removeSsr()
      })
    })

    openBoot()

    if (isIslandReadyRoute(window.location.pathname)) {
      waitForIslandReady()
    } else {
      if (forceCloseTimerRef.current) clearTimeout(forceCloseTimerRef.current)
      forceCloseTimerRef.current = setTimeout(() => {
        readyRef.current = true
        scheduleClose()
      }, maxWaitMs)
    }

    return () => {
      if (forceCloseTimerRef.current) clearTimeout(forceCloseTimerRef.current)
    }
  }, [maxWaitMs])

  useEffect(() => {
    const onStart = () => {
      clickNavArmedRef.current = true
      openNav(false)
    }

    window.addEventListener('phantasm:splashStart', onStart)
    return () => window.removeEventListener('phantasm:splashStart', onStart)
  }, [])

  const lastPathRef = useRef(pathname)

  useLayoutEffect(() => {
    const prev = lastPathRef.current
    if (pathname === prev) return
    lastPathRef.current = pathname

    if (!open && !clickNavArmedRef.current) {
      openNav(true)

      if (isIslandReadyRoute(pathname)) {
        waitForIslandReady()
      } else {
        readyRef.current = true
        scheduleClose()
      }

      return
    }

    if (modeRef.current === 'nav') {
      clickNavArmedRef.current = false

      if (isIslandReadyRoute(pathname)) {
        waitForIslandReady()
      } else {
        readyRef.current = true
        scheduleClose()
      }

      return
    }

    if (modeRef.current === 'boot') {
      if (isIslandReadyRoute(pathname)) {
        waitForIslandReady()
      } else {
        readyRef.current = true
        scheduleClose()
      }
    }
  }, [pathname, open])

  useEffect(() => {
    if (open) return

    const id = window.setTimeout(() => {
      try {
        sessionStorage.setItem('phantasm:splashFullyClosed', '1')
        window.dispatchEvent(new CustomEvent('phantasm:splashFullyClosed'))
      } catch {}
    }, 40)

    return () => window.clearTimeout(id)
  }, [open])

  return <SplashOverlay open={open} isInstant={isInstant} />
}
